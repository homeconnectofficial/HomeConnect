import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const properties = [
  { id: 1, title: "Modern Family Home", location: "Gaborone, Block 8", price: 1850000, beds: 4, baths: 3, type: "House", image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80" },
  { id: 2, title: "Contemporary Townhouse", location: "Gaborone, Phakalane", price: 1450000, beds: 3, baths: 2, type: "Townhouse", image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80" },
  { id: 3, title: "Affordable Starter Home", location: "Gaborone, Mogoditshane", price: 895000, beds: 3, baths: 2, type: "House", image: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80" },
  { id: 4, title: "Luxury Garden Villa", location: "Gaborone, Kgale", price: 2950000, beds: 5, baths: 4, type: "Villa", image: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1200&q=80" }
];

function money(value) {
  return new Intl.NumberFormat("en-BW", {
    style: "currency",
    currency: "BWP",
    maximumFractionDigits: 0
  }).format(value);
}

function App() {
  const [query, setQuery] = useState("");
  const [type, setType] = useState("All");
  const [saved, setSaved] = useState([]);
  const [menu, setMenu] = useState(false);

  const filtered = useMemo(() => properties.filter(p => {
    const text = `${p.title} ${p.location}`.toLowerCase();
    return text.includes(query.toLowerCase()) && (type === "All" || p.type === type);
  }), [query, type]);

  const toggleSaved = (id) => {
    setSaved(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  };

  return (
    <div className="app">
      <header className="header">
        <div className="container nav">
          <div className="brand">
            <div className="logo">H</div>
            <div>
              <strong>HomeConnect</strong>
              <span>Botswana property marketplace</span>
            </div>
          </div>
          <button className="menuBtn" onClick={() => setMenu(!menu)}>☰</button>
          <nav className={menu ? "navLinks open" : "navLinks"}>
            <a href="#homes">Find a Home</a>
            <a href="#saved">Saved ({saved.length})</a>
            <a href="#sell">Sell a Property</a>
            <button className="profileBtn">Sign in</button>
          </nav>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="container heroInner">
            <div className="heroCopy">
              <p className="eyebrow">YOUR NEXT HOME STARTS HERE</p>
              <h1>Find a place you'll love to call <span>home.</span></h1>
              <p className="heroText">Discover homes, apartments and land for sale across Botswana. Connect directly with sellers and property companies.</p>
              <div className="searchBox">
                <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search Gaborone, Phakalane, Mogoditshane..." />
                <button onClick={() => document.getElementById("homes").scrollIntoView({ behavior: "smooth" })}>Search</button>
              </div>
            </div>
            <div className="heroCard">
              <div className="heroStat"><strong>{properties.length}+</strong><span>Featured homes</span></div>
              <div className="heroStat"><strong>BW</strong><span>Built for Botswana</span></div>
              <div className="heroStat"><strong>24/7</strong><span>Connect with sellers</span></div>
            </div>
          </div>
        </section>

        <section className="container section" id="homes">
          <div className="sectionHead">
            <div>
              <p className="eyebrow">EXPLORE</p>
              <h2>Featured properties</h2>
            </div>
            <select value={type} onChange={e => setType(e.target.value)}>
              <option>All</option>
              <option>House</option>
              <option>Townhouse</option>
              <option>Villa</option>
            </select>
          </div>

          <div className="grid">
            {filtered.map(p => (
              <article className="property" key={p.id}>
                <div className="photo">
                  <img src={p.image} alt={p.title} />
                  <button className={saved.includes(p.id) ? "heart saved" : "heart"} onClick={() => toggleSaved(p.id)} aria-label="Save property">
                    {saved.includes(p.id) ? "♥" : "♡"}
                  </button>
                  <span className="badge">{p.type}</span>
                </div>
                <div className="propertyBody">
                  <p className="price">{money(p.price)}</p>
                  <h3>{p.title}</h3>
                  <p className="location">📍 {p.location}</p>
                  <div className="details"><span>🛏 {p.beds} beds</span><span>🚿 {p.baths} baths</span></div>
                  <button className="viewBtn">View property</button>
                </div>
              </article>
            ))}
          </div>

          {filtered.length === 0 && <div className="empty">No properties matched your search.</div>}
        </section>

        <section className="container cta" id="sell">
          <div>
            <p className="eyebrow">FOR SELLERS</p>
            <h2>Have a property to sell?</h2>
            <p>List your property on HomeConnect and connect with buyers looking across Botswana.</p>
          </div>
          <button>List a property</button>
        </section>
      </main>

      <footer>
        <div className="container footer">
          <div><strong>HomeConnect</strong><p>Making property discovery easier in Botswana.</p></div>
          <p>© 2026 HomeConnect. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
