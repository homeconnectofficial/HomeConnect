# HomeConnect

HomeConnect is a starter property marketplace for Botswana.

## Current starter features
- Green-and-white real-estate interface
- Property search
- Property-type filtering
- Save/favourite properties
- Responsive mobile layout
- Seller call-to-action
- Render-ready Node/Vite configuration

## Run locally

```bash
npm install
npm run dev
```

## Render

For a static React/Vite frontend, the simplest production setup is:
- Runtime: Node
- Build Command: `npm install && npm run build`
- Start Command: `npm run start`
- Root Directory: blank
- Environment variables: none required for this starter

This starter does not yet connect to PostgreSQL. Database/auth/messaging APIs can be added in the next stage.
